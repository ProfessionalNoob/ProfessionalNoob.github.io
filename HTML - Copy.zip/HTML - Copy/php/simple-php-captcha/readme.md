# A simple PHP CAPTCHA script

_Written by Cory LaViska for A Beautiful Site, LLC.  (http://abeautifulsite.net/)_

_Licensed under the MIT license: http://opensource.org/licenses/MIT_

## Demo and Usage

http://labs.abeautifulsite.net/simple-php-captcha/

## Attribution

 - Special thanks to Subtle Patterns for the patterns used for default backgrounds: http://subtlepatterns.com/
 - Special thanks to dafont.com for providing Times New Yorker: http://www.dafont.com/